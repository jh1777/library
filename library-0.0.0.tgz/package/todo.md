# UI Lib Status

CS - Component Store

## Aktuell in Arbeit

Umstellen auf aktuelles CS pattern

## Ohne CS

- /button (DONE)
- /metric-entry -> Model vereinheitlichen (s.u.)
- /property-entry -> Model vereinheitlichen (s.u.)
- /property-grid -> Model vereinheitlichen (s.u.), neue Components 1 und 2 aufnehmen
- /tags -> todo!, Cy tests
- /drawer-right -> todo! duplizieren und zurückbauen auf normales model ohne CS
- /drawer-entry -> todo! duplizieren und zurückbauen auf normales model ohne CS

## Mit CS

> (* without Cypress)

- /button-cs (DONE*)
- /metric-entry-cs (DONE*)  -> umstellen auf (initialized) event
- /property-entry-cs (DONE*)  -> umstellen auf (initialized) event
- /drawer-right-cs -> (DONE*)  -> umstellen auf (initialized) event
- /drawer-entry-cs -> umstellen auf (initialized) event
- /tags-cs -> umstellen auf (initialized) event, Cy tests!
- /property-grid-cs -> todo!, duplizieren und auf CS umstellen,  -> umstellen auf (initialized) event


# New Components

1. property-entry-simple (only 1 Key/Value) -> integrate in grid


# ToDo

- OnClick emitter sollten alle die id emitten, die jede component als Input() property besitzen sollte

- Alle non-Component Store models vereinheitlichen in einem Model 
    - teil-interface erstellen für error

# Links

- Deep Merge package -> https://www.npmjs.com/package/deepmerge 