import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = "Title"; // for testing
  public showBorders: boolean = false;

  public buttonsTabActive: boolean;
  public tagsTabActive: boolean;
  public drawerTabActive: boolean;
  public entriesTabActive: boolean;
  public entryGridTabActive: boolean;
  public entryTileTabActive: boolean;
  public uiLibTabActive: boolean;
  
}